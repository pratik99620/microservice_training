package com.library.subscription.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.library.subscription.pojo.Subscription;

public interface SubscriptionRepository extends JpaRepository<Subscription, String>{

}
