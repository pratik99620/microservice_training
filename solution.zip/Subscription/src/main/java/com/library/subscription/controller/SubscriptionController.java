package com.library.subscription.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.library.subscription.pojo.Subscription;
import com.library.subscription.repository.SubscriptionRepository;
import com.library.subscription.service.SubscriptionService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
public class SubscriptionController {

	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	@Autowired
	SubscriptionService subscriptionService;

	@GetMapping("/subscriptions")
	public ResponseEntity<?> getSubscriptionByName(){
		return new ResponseEntity<>(subscriptionRepository.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/subscriptionsByName/{name}")
	public ResponseEntity<?> getSubscriptionByName(@PathVariable("name")String name){
		return new ResponseEntity<>(subscriptionRepository.findById(name),HttpStatus.OK);
	}
	
	@PostMapping("/subscriptions")
	public ResponseEntity<?> addSubscription(@RequestBody Subscription subscription){
		
		int flag = subscriptionService.addSubscription(subscription);
		System.out.println("incontroller flag "+flag);
		if (flag==1) {
	        return new ResponseEntity<>(
	          "Successful creation of subscription record", 
	          HttpStatus.CREATED);
	    }
		
	    return new ResponseEntity<>(
	      "Book is not available or service is down",HttpStatus.PARTIAL_CONTENT);
	}
	
}
