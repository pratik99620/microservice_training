package com.library.subscription.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.library.subscription.pojo.Subscription;
import com.library.subscription.repository.SubscriptionRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Transactional 
@Service
public class SubscriptionService {
	
	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	@CircuitBreaker(fallbackMethod = "failbackMethod", name = "apitest")
	public int addSubscription(Subscription subscription) {
		String uri="http://localhost:8080/noOfCopies/"+subscription.getBookId();
		RestTemplate restTemplate= new RestTemplate();
		Long noOfCopies = restTemplate.getForObject(uri, Long.class);
		if(noOfCopies>0) {
			subscriptionRepository.save(subscription);
			return 1;
		}
		return 0;
		
	}
	
	public int failbackMethod(Throwable ex) {
		System.out.println("in service failback");
		return 0;
	}

}
