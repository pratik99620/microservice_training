package com.library.subscription.pojo;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity(name="subscription")
public class Subscription {
    
	@Id
	@Column(name="subscription_name")
	private String subscriptionName;
 
	@Column(name="book_id")
	private String bookId;
    
	@Column(name="date_subscribed")
	private Date dateSubscribed;
	
	
	@Column(name="date_return ")
	private Date dateReturned;
	
	public Subscription() {
	
	}

	
	
	
	public Subscription(String subscriptionName, String bookId, Date dateSubscribed, Date dateReturned) {
		super();
		this.subscriptionName = subscriptionName;
		this.bookId = bookId;
		this.dateSubscribed = dateSubscribed;
		this.dateReturned = dateReturned;
	}




	public String getSubscriptionName() {
		return subscriptionName;
	}

	public void setSubscriptionName(String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public Date getDateSubscribed() {
		return dateSubscribed;
	}

	public void setDateSubscribed(Date dateSubscribed) {
		this.dateSubscribed = dateSubscribed;
	}

	public Date getDateReturned() {
		return dateReturned;
	}

	public void setDateReturned(Date dateReturned) {
		this.dateReturned = dateReturned;
	}

	@Override
	public String toString() {
		return "Subscription [subscriptionName=" + subscriptionName + ", bookId=" + bookId + ", dateSubscribed="
				+ dateSubscribed + ", dateReturned=" + dateReturned + "]";
	}

	
	
	
    
}
