package com.example.eureksService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EureksServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
